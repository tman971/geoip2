# geoip

Docker image for [GeoLite2](http://dev.maxmind.com/geoip/geoip2/geolite2/)
Country and City databases, updated weekly.

**Note this is currently broken because MaxMind changed the availability of their DB files**
